# Hamna Mohsin Portfolio

## GitHub Pages Setup

1. Upload this ZIP content to your GitHub repository
2. Go to Settings → Pages
3. Set Source to 'main' branch, root folder
4. Your portfolio will be live at: https://yourusername.github.io/repo-name

## Files
- index.html — Main portfolio file
- assets/images/ — Profile and logo images
